package com.example.shoshinapp

import android.app.Activity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class PhoneAuthManager(private val auth: FirebaseAuth) {
    
    var verificationId: String? = null
    
    fun startPhoneAuth(
        phone: String,
        activity: Activity,
        onCodeSent: (verificationId: String) -> Unit,
        onError: (Exception) -> Unit
    ) {
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                // Auto-retrieval or instant verification
            }

            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                verificationId = id
                onCodeSent(id)
            }

            override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                onError(e)
            }
        }

        PhoneAuthProvider.getInstance(auth).verifyPhoneNumber(
            phone,
            60L,
            TimeUnit.SECONDS,
            activity,
            callbacks
        )
    }
}
