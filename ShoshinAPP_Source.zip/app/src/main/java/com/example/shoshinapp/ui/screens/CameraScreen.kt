package com.example.shoshinapp.ui.screens

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.shoshinapp.data.db.AppDatabase
import com.example.shoshinapp.data.db.entities.PhotoEntity
import com.example.shoshinapp.ui.components.ShoshinButton
import com.example.shoshinapp.ui.theme.*
import com.example.shoshinapp.utils.PhotoStorageManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.util.UUID

@Composable
fun CameraScreen(
    navController: NavController,
    template: String = "walk",
    current: Int = 0,
    database: AppDatabase? = null
) {
    var showCamera by remember { mutableStateOf(true) }
    var capturedImage by remember { mutableStateOf<Bitmap?>(null) }
    var isUploading by remember { mutableStateOf(false) }
    var uploadError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    
    val photoStorageManager = remember { PhotoStorageManager(context) }

    if (showCamera) {
        CameraPreviewUI(
            onPhotoCapture = { bitmap ->
                capturedImage = bitmap
                showCamera = false
            },
            onDismiss = { navController.popBackStack() }
        )
    } else {
        CameraPreviewScreen(
            bitmap = capturedImage,
            isUploading = isUploading,
            error = uploadError,
            onRetake = {
                capturedImage = null
                showCamera = true
                uploadError = null
            },
            onConfirm = {
                capturedImage?.let { bitmap ->
                    isUploading = true
                    scope.launch {
                        uploadPhotoToFirebase(
                            bitmap,
                            context,
                            database!!,
                            photoStorageManager,
                            onSuccess = {
                                isUploading = false
                                navController.popBackStack()
                            },
                            onError = { error ->
                                isUploading = false
                                uploadError = error
                            }
                        )
                    }
                }
            }
        )
    }
}

@Composable
fun CameraPreviewUI(onPhotoCapture: (Bitmap) -> Unit, onDismiss: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(Ink)) {
        Box(modifier = Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) {
            Text("📷 Camera Preview", color = Paper, fontSize = 18.sp)
        }

        Box(
            modifier = Modifier.fillMaxWidth().height(100.dp).background(Night),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = Paper)
                }

                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .border(3.dp, Vermillion, RoundedCornerShape(50))
                        .clickable {
                            val bitmap = Bitmap.createBitmap(412, 600, Bitmap.Config.ARGB_8888)
                            onPhotoCapture(bitmap)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .background(Vermillion, RoundedCornerShape(50))
                    )
                }

                IconButton(onClick = { }) {
                    Text("⚡", fontSize = 24.sp)
                }
            }
        }
    }
}

@Composable
fun CameraPreviewScreen(
    bitmap: Bitmap?,
    isUploading: Boolean,
    error: String?,
    onRetake: () -> Unit,
    onConfirm: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(rememberScrollState())
    ) {
        if (!isUploading) {
            TextButton(onClick = onRetake, modifier = Modifier.align(Alignment.End)) {
                Text("Retake", color = Vermillion)
            }
        }

        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Captured photo",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(1.dp, Paper2, RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (error != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFEBEE), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text("❌ Error: $error", color = Color(0xFFC62828), fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        Text(
            if (isUploading) "⏳ Uploading to cloud..." else "✅ Photo ready",
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))

        if (isUploading) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            )
        } else {
            ShoshinButton(
                label = "Continue",
                onClick = onConfirm,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

suspend fun uploadPhotoToFirebase(
    bitmap: Bitmap,
    context: Context,
    database: AppDatabase,
    photoStorageManager: PhotoStorageManager,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    try {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
            ?: throw Exception("User not authenticated")

        // 1. Compress and save locally
        val compressionResult = photoStorageManager.saveCompressedPhoto(bitmap)
        if (!compressionResult.isSuccess) {
            onError("Failed to compress photo")
            return
        }

        val localPath = compressionResult.getOrNull() ?: ""
        val photoId = UUID.randomUUID().toString()

        // 2. Save to local Room database FIRST
        val photoEntity = PhotoEntity(
            photoId = photoId,
            userId = userId,
            localCompressedPath = localPath,
            firebaseUrl = null,
            date = java.time.LocalDate.now().toString(),
            timestamp = System.currentTimeMillis(),
            syncStatus = "pending"
        )

        database.photoDao().insertPhoto(photoEntity)
        onSuccess() // Show success immediately

        // 3. Upload to Firebase Storage in background
        val storage = FirebaseStorage.getInstance()
        val filename = "checkpoints/${userId}/${photoId}.jpg"
        val storageRef = storage.reference.child(filename)

        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, baos)
        val imageData = baos.toByteArray()

        storageRef.putBytes(imageData)
            .addOnSuccessListener { taskSnapshot ->
                storageRef.downloadUrl.addOnSuccessListener { uri ->
                    CoroutineScope(Dispatchers.IO).launch {
                        database.photoDao().updatePhoto(
                            photoEntity.copy(
                                firebaseUrl = uri.toString(),
                                syncStatus = "synced"
                            )
                        )
                    }
                }
            }
            .addOnFailureListener {
                // Keep as pending for retry during sync
            }
    } catch (e: Exception) {
        onError(e.localizedMessage ?: "Unknown error")
    }
}
