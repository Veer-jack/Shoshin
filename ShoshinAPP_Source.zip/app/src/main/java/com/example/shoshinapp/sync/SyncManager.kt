package com.example.shoshinapp.sync

import android.util.Log
import com.example.shoshinapp.data.AuthRepository
import com.example.shoshinapp.data.db.AppDatabase
import com.example.shoshinapp.data.db.entities.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.Gson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

sealed class SyncState {
    object Idle : SyncState()
    object Syncing : SyncState()
    data class Success(val message: String) : SyncState()
    data class Error(val message: String) : SyncState()
    data class Conflict(val entityId: String) : SyncState()
}

class SyncManager(
    private val db: AppDatabase,
    private val firestore: FirebaseFirestore,
    private val authRepository: AuthRepository,
    private val conflictResolver: ConflictResolver
) {

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val gson = Gson()
    private val TAG = "SyncManager"

    suspend fun syncAll() {
        try {
            val userId = authRepository.getCurrentUser()?.uid ?: return
            _syncState.value = SyncState.Syncing

            // Sync reflections
            syncReflections(userId)

            // Sync streaks
            syncStreaks(userId)

            // Sync photos
            syncPhotos(userId)

            _syncState.value = SyncState.Success("Sync completed successfully")
            Log.d(TAG, "Sync completed for user: $userId")
        } catch (e: Exception) {
            _syncState.value = SyncState.Error(e.message ?: "Sync failed")
            Log.e(TAG, "Sync error", e)
        }
    }

    private suspend fun syncReflections(userId: String) {
        val pendingReflections = db.reflectionDao().getPendingReflections(userId)

        for (local in pendingReflections) {
            try {
                val remoteDoc = firestore
                    .collection("reflections")
                    .document(userId)
                    .collection("entries")
                    .document(local.reflectionId)
                    .get()
                    .await()

                if (remoteDoc.exists()) {
                    val remote = remoteDoc.toObject(ReflectionEntity::class.java) ?: continue

                    // Check for conflict
                    if (local.version < remote.version && local.content != remote.content) {
                        handleReflectionConflict(userId, local, remote)
                        return
                    }
                }

                // Push to Firebase
                firestore
                    .collection("reflections")
                    .document(userId)
                    .collection("entries")
                    .document(local.reflectionId)
                    .set(local)
                    .await()

                // Mark as synced
                db.reflectionDao().updateReflection(
                    local.copy(syncStatus = "synced")
                )
                Log.d(TAG, "Synced reflection: ${local.reflectionId}")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing reflection ${local.reflectionId}", e)
            }
        }

        // Pull fresh data from Firebase
        pullRemoteReflections(userId)
    }

    private suspend fun syncStreaks(userId: String) {
        val pendingStreaks = db.streakDao().getPendingStreaks(userId)

        for (streak in pendingStreaks) {
            try {
                firestore
                    .collection("streaks")
                    .document(userId)
                    .collection("entries")
                    .document(streak.streakId)
                    .set(streak)
                    .await()

                db.streakDao().updateStreak(
                    streak.copy(syncStatus = "synced")
                )
                Log.d(TAG, "Synced streak: ${streak.streakId}")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing streak ${streak.streakId}", e)
            }
        }

        // Pull fresh data
        pullRemoteStreaks(userId)
    }

    private suspend fun syncPhotos(userId: String) {
        val pendingPhotos = db.photoDao().getPendingPhotos(userId)

        for (photo in pendingPhotos) {
            try {
                firestore
                    .collection("photos")
                    .document(userId)
                    .collection("entries")
                    .document(photo.photoId)
                    .set(photo)
                    .await()

                db.photoDao().updatePhoto(
                    photo.copy(syncStatus = "synced")
                )
                Log.d(TAG, "Synced photo: ${photo.photoId}")
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing photo ${photo.photoId}", e)
            }
        }

        // Pull fresh data
        pullRemotePhotos(userId)
    }

    private suspend fun pullRemoteReflections(userId: String) {
        try {
            val docs = firestore
                .collection("reflections")
                .document(userId)
                .collection("entries")
                .get()
                .await()

            for (doc in docs) {
                val remote = doc.toObject(ReflectionEntity::class.java) ?: continue
                val local = db.reflectionDao().getReflection(remote.reflectionId)

                if (local == null) {
                    db.reflectionDao().insertReflection(
                        remote.copy(syncStatus = "synced")
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pulling reflections", e)
        }
    }

    private suspend fun pullRemoteStreaks(userId: String) {
        try {
            val docs = firestore
                .collection("streaks")
                .document(userId)
                .collection("entries")
                .get()
                .await()

            for (doc in docs) {
                val remote = doc.toObject(StreakEntity::class.java) ?: continue
                db.streakDao().insertStreak(
                    remote.copy(syncStatus = "synced")
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pulling streaks", e)
        }
    }

    private suspend fun pullRemotePhotos(userId: String) {
        try {
            val docs = firestore
                .collection("photos")
                .document(userId)
                .collection("entries")
                .get()
                .await()

            for (doc in docs) {
                val remote = doc.toObject(PhotoEntity::class.java) ?: continue
                db.photoDao().insertPhoto(
                    remote.copy(syncStatus = "synced")
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pulling photos", e)
        }
    }

    private suspend fun handleReflectionConflict(
        userId: String,
        local: ReflectionEntity,
        remote: ReflectionEntity
    ) {
        _syncState.value = SyncState.Conflict(local.reflectionId)

        conflictResolver.resolveReflectionConflict(local, remote) { resolution ->
            // Handle resolution in UI
        }
    }
}