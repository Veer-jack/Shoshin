package com.example.shoshinapp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shoshinapp.ui.theme.*

@Composable
fun SyncStatusDialog(
    isVisible: Boolean,
    status: String, // "syncing", "success", "error", "offline"
    message: String = "",
    onDismiss: () -> Unit
) {
    if (!isVisible) return

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(16.dp),
        containerColor = Paper,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (status) {
                    "syncing" -> {
                        CircularProgressIndicator(
                            color = Vermillion,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Syncing...",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Ink
                        )
                    }
                    "success" -> {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Success",
                            tint = Matcha,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Sync Successful",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Ink
                        )
                    }
                    "error" -> {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = "Error",
                            tint = Vermillion,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Sync Failed",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Ink
                        )
                    }
                    "offline" -> {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = "Offline",
                            tint = Color(0xFFFFA500),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "You're Offline",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Ink
                        )
                    }
                }

                if (message.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        message,
                        fontSize = 14.sp,
                        color = Fog,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.padding(8.dp)
            ) {
                Text("OK", color = Vermillion)
            }
        }
    )
}

@Composable
fun OfflineIndicator(isOffline: Boolean) {
    if (!isOffline) return

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFFFE5B4))
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Warning,
                contentDescription = "Offline",
                tint = Color(0xFFFFA500),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "📵 You're offline - Changes saved locally",
                fontSize = 12.sp,
                color = Ink,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun ConflictResolutionDialog(
    isVisible: Boolean,
    localContent: String,
    remoteContent: String,
    onUseLocal: () -> Unit,
    onUseRemote: () -> Unit,
    onMerge: () -> Unit
) {
    if (!isVisible) return

    AlertDialog(
        onDismissRequest = { },
        shape = RoundedCornerShape(16.dp),
        containerColor = Paper,
        title = {
            Text(
                "Conflict Detected",
                fontWeight = FontWeight.SemiBold,
                color = Ink
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Text(
                    "This reflection was edited elsewhere. Which version do you prefer?",
                    fontSize = 14.sp,
                    color = Fog,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Local version
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFE8F5E9), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        "Your Version:\n$localContent",
                        fontSize = 12.sp,
                        color = Ink
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Remote version
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFFEBEE), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        "Cloud Version:\n$remoteContent",
                        fontSize = 12.sp,
                        color = Ink
                    )
                }
            }
        },
        confirmButton = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onUseLocal,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Matcha)
                ) {
                    Text("Keep My Version", color = Paper)
                }

                Button(
                    onClick = onUseRemote,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Vermillion)
                ) {
                    Text("Use Cloud Version", color = Paper)
                }

                Button(
                    onClick = onMerge,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                ) {
                    Text("Merge Both", color = Paper)
                }
            }
        }
    )
}