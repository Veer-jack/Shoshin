package com.example.shoshinapp

import android.content.Context
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import kotlinx.coroutines.tasks.await

class GoogleAuthManager(context: Context) {
    
    private val googleSignInClient: GoogleSignInClient = GoogleSignIn.getClient(
        context,
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("YOUR_WEB_CLIENT_ID")
            .requestEmail()
            .build()
    )

    suspend fun signIn(): Result<String> {
        return try {
            val task = googleSignInClient.signInIntent
            // Return intent for UI to handle
            Result.success("ready")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getSignInIntent() = googleSignInClient.signInIntent

    fun signOut() = googleSignInClient.signOut()
}
