package com.example.shoshinapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.shoshinapp.sync.*
import com.example.shoshinapp.ui.components.*
import com.example.shoshinapp.ui.theme.*

@Composable
fun HomeScreen(
    navController: NavController,
    syncManager: SyncManager? = null,
    networkMonitor: NetworkStateMonitor? = null,
    conflictResolver: ConflictResolver? = null
) {
    val isOffline by networkMonitor?.isOnline?.collectAsState(initial = true) ?: remember { mutableStateOf(true) }
    val syncState by syncManager?.syncState?.collectAsState(initial = SyncState.Idle) ?: remember { mutableStateOf(SyncState.Idle) }
    val conflictDialog by conflictResolver?.conflictDialog?.collectAsState(initial = null) ?: remember { mutableStateOf(null) }
    
    var showSyncDialog by remember { mutableStateOf(false) }
    var syncMessage by remember { mutableStateOf("") }

    LaunchedEffect(syncState) {
        when (syncState) {
            is SyncState.Syncing -> {
                showSyncDialog = true
                syncMessage = "Syncing..."
            }
            is SyncState.Success -> {
                showSyncDialog = true
                syncMessage = (syncState as SyncState.Success).message
            }
            is SyncState.Error -> {
                showSyncDialog = true
                syncMessage = (syncState as SyncState.Error).message
            }
            is SyncState.Conflict -> {
                syncMessage = "Conflict detected"
            }
            else -> {}
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Paper)
    ) {
        // Offline indicator
        OfflineIndicator(isOffline = !isOffline)

        // Sync status bar
        if (syncState !is SyncState.Idle) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        when (syncState) {
                            is SyncState.Syncing -> Color(0xFFE3F2FD)
                            is SyncState.Success -> Color(0xFFE8F5E9)
                            is SyncState.Error -> Color(0xFFFFEBEE)
                            else -> Paper
                        }
                    )
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        Icons.Default.Sync,
                        contentDescription = "Sync",
                        tint = when (syncState) {
                            is SyncState.Syncing -> Color(0xFF1976D2)
                            is SyncState.Success -> Matcha
                            is SyncState.Error -> Vermillion
                            else -> Ink
                        },
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        when (syncState) {
                            is SyncState.Syncing -> "⏳ Syncing changes..."
                            is SyncState.Success -> "✅ ${(syncState as SyncState.Success).message}"
                            is SyncState.Error -> "❌ ${(syncState as SyncState.Error).message}"
                            else -> ""
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Ink
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Text(
                "🌅 Good Morning",
                fontSize = 32.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink
            )

            // Quick stats
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Washi, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("12", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Day Streak", fontSize = 12.sp, color = Fog)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("47", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Best Streak", fontSize = 12.sp, color = Fog)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("124", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Total Days", fontSize = 12.sp, color = Fog)
                }
            }

            // Action button
            ShoshinButton(
                label = "Start Morning Routine",
                onClick = { navController.navigate("alarm") },
                modifier = Modifier.fillMaxWidth()
            )

            // Navigation buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ShoshinButton(
                    label = "Streaks",
                    onClick = { navController.navigate("consistency") },
                    modifier = Modifier.weight(1f)
                )
                ShoshinButton(
                    label = "Profile",
                    onClick = { navController.navigate("profile") },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    // Sync dialog
    SyncStatusDialog(
        isVisible = showSyncDialog,
        status = when (syncState) {
            is SyncState.Syncing -> "syncing"
            is SyncState.Success -> "success"
            is SyncState.Error -> "error"
            else -> ""
        },
        message = syncMessage,
        onDismiss = { showSyncDialog = false }
    )

    // CONFLICT RESOLUTION DIALOG
    conflictDialog?.let { conflict ->
        ConflictResolutionDialog(
            isVisible = conflictDialog != null,
            localContent = conflict.local.content.take(50),
            remoteContent = conflict.remote.content.take(50),
            onUseLocal = {
                conflictResolver?.resolveWithLocal(conflict.local)
            },
            onUseRemote = {
                conflictResolver?.resolveWithRemote(conflict.remote)
            },
            onMerge = {
                conflictResolver?.resolveWithMerge(conflict.local, conflict.remote)
            }
        )
    }
}
