package com.example.shoshinapp.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.shoshinapp.data.db.AppDatabase
import com.example.shoshinapp.sync.*
import com.example.shoshinapp.ui.screens.*

@Composable
fun ShoshinNavGraph(
    database: AppDatabase,
    syncManager: SyncManager,
    networkMonitor: NetworkStateMonitor,
    conflictResolver: ConflictResolver
) {
    val navController = rememberNavController()
    
    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                navController = navController,
                syncManager = syncManager,
                networkMonitor = networkMonitor,
                conflictResolver = conflictResolver
            )
        }
        composable("camera") {
            CameraScreen(
                navController = navController,
                database = database
            )
        }
        composable("editor") {
            EditorScreen(
                navController = navController,
                database = database
            )
        }
        // Add other routes as needed
        composable("alarm") { /* Placeholder */ }
        composable("consistency") { /* Placeholder */ }
        composable("profile") { /* Placeholder */ }
    }
}
