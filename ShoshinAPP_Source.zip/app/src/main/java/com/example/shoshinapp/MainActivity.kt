package com.example.shoshinapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.setContent
import com.example.shoshinapp.data.AuthRepository
import com.example.shoshinapp.data.db.AppDatabase
import com.example.shoshinapp.sync.*
import com.example.shoshinapp.ui.ShoshinNavGraph
import com.example.shoshinapp.ui.theme.ShoshinAPPTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    
    private lateinit var authRepository: AuthRepository
    private lateinit var syncManager: SyncManager
    private lateinit var networkMonitor: NetworkStateMonitor
    private lateinit var conflictResolver: ConflictResolver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase and local database
        val firebaseAuth = FirebaseAuth.getInstance()
        val firestore = FirebaseFirestore.getInstance()
        val database = AppDatabase.getInstance(applicationContext)

        authRepository = AuthRepository(firebaseAuth)
        conflictResolver = ConflictResolver()
        syncManager = SyncManager(database, firestore, authRepository, conflictResolver)
        networkMonitor = NetworkStateMonitor(applicationContext)

        // Schedule background sync
        SyncWorker.scheduleSyncWork(applicationContext)

        setContent {
            ShoshinAPPTheme {
                ShoshinNavGraph(
                    database = database,
                    syncManager = syncManager,
                    networkMonitor = networkMonitor,
                    conflictResolver = conflictResolver
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        SyncWorker.cancelSyncWork(applicationContext)
    }
}
