package com.example.shoshinapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.shoshinapp.data.db.AppDatabase
import com.example.shoshinapp.data.db.entities.ReflectionEntity
import com.example.shoshinapp.ui.components.ShoshinButton
import com.example.shoshinapp.ui.components.ShoshinTextField
import com.example.shoshinapp.ui.theme.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import java.util.UUID

@Composable
fun EditorScreen(
    navController: NavController,
    template: String = "walk",
    database: AppDatabase? = null
) {
    var text by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    
    val userId = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Paper)
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            "📝 Reflection",
            fontSize = 28.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = CormorantGaramond,
            color = Ink
        )
        Text(
            "Write about your morning",
            fontSize = 14.sp,
            color = Fog,
            fontFamily = DMSans
        )

        Spacer(modifier = Modifier.height(24.dp))

        ShoshinTextField(
            value = text,
            onValueChange = { text = it },
            placeholder = "Start typing your thoughts...",
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            if (isSaving) "⏳ Saving locally..." else "✅ Ready to save",
            fontSize = 11.sp,
            color = if (isSaving) Color(0xFFFFA500) else Matcha,
            fontFamily = DMSans
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (saveStatus.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (saveStatus.contains("✅")) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(12.dp)
            ) {
                Text(
                    saveStatus,
                    fontSize = 12.sp,
                    color = if (saveStatus.contains("✅")) Matcha else Vermillion,
                    fontFamily = DMSans
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        ShoshinButton(
            label = if (isSaving) "Saving..." else "Save Reflection",
            onClick = {
                if (text.isNotEmpty()) {
                    isSaving = true
                    scope.launch {
                        saveReflectionToFirebase(text, userId, database!!) { success ->
                            isSaving = false
                            saveStatus = if (success) "✅ Saved (syncing...)" else "❌ Failed"
                            if (success) {
                                scope.launch {
                                    delay(1500)
                                    navController.popBackStack()
                                }
                            }
                        }
                    }
                } else {
                    saveStatus = "❌ Please write something"
                }
            },
            enabled = !isSaving
        )
    }
}

suspend fun saveReflectionToFirebase(
    text: String,
    userId: String,
    database: AppDatabase,
    onComplete: (Boolean) -> Unit
) {
    try {
        val reflectionId = UUID.randomUUID().toString()
        val reflection = ReflectionEntity(
            reflectionId = reflectionId,
            userId = userId,
            content = text,
            date = java.time.LocalDate.now().toString(),
            timestamp = System.currentTimeMillis(),
            syncStatus = "pending"
        )

        // 1. Save to local database FIRST
        database.reflectionDao().insertReflection(reflection)
        onComplete(true) // Show success immediately

        // 2. Push to Firestore in background (don't wait)
        val firestore = FirebaseFirestore.getInstance()
        firestore
            .collection("reflections")
            .document(userId)
            .collection("entries")
            .document(reflectionId)
            .set(reflection)
            .addOnSuccessListener {
                // Mark as synced
                CoroutineScope(Dispatchers.IO).launch {
                    database.reflectionDao().updateReflection(
                        reflection.copy(syncStatus = "synced")
                    )
                }
            }
            .addOnFailureListener {
                // Keep as pending for retry
            }
    } catch (e: Exception) {
        onComplete(false)
    }
}
